module.exports = function (api) {
  api.cache(true);
  return {
    presets: ["babel-preset-expo"],
    // react-native-reanimated's plugin MUST be listed last — it rewrites
    // worklets and needs to run after every other transform.
    plugins: ["react-native-reanimated/plugin"],
  };
};
